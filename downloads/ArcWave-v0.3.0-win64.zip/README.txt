﻿ArcWave v0.3.0 - Windows x64 VST3

1) Extract this folder.
2) Run install-vst3.bat (admin) or add this folder to your DAW's VST3 search paths.
3) Rescan plugins.

License: GNU AGPLv3. See LICENSE.
Not affiliated with Image-Line.
